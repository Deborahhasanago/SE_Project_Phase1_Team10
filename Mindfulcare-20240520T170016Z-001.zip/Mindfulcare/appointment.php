<?php
  
  include_once './configure/function.php';

?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link href="style.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    </head>
    <body>  
      <div class="container">
      <button class="backbtn" onclick="location.href='./landingpage.php'"><img src="./images/back.png" alt="">Go to homepage</button>
     <div class="row align-items-center">
          <div class="col-md-6 text-center">
                  <div class="appoinment-content">
                        <img src="./images/abtus.png" alt="" class="img-fluid"/>
                   </div>
                
                </div>

         <div class="col-md-6">
         <div class="card ">
          <div class="card-header bg-success">
          <h4 class="text-white">BOOK APPOINMENT</h4>
          </div>
          <div class="card-body">
            
          <form action="base.php" method="POST">
              <div class="mb-3"> 
            <label>Name</label>
                <input type="text" name="name" class="form-control">
                </div>
                <div class="mb-3"> 
            <label>Date</label>
            <input name="date" type="date" class="form-control" placeholder="dd/mm/yyyy">
                </div>
                <div class="mb-3"> 
                <label>Time</label>
                <input name="time"  type="time" class="form-control" placeholder="Time">
                </div>
                <div class="mb-3"> 
            <label>Email</label>
                <input type="email" name="email" class="form-control">
                </div>
                <div class="mb-3"> 
                <label>Phone Number</label>
                <input type="text" name="phone" class="form-control">
                </div>
                <div class="mb-3">
                <label>Message</label>
                <textarea name="message" class="form-control" rows="2"></textarea>
                </div>
                <div class="mb-3">
                    <button type="submit" name="bookBtn" class="btn btn-primary">BOOK</button>
                </div>
            </div>

                



            </form>
          </div>
        </div>
          </div>

        </div>
                        
    </div>




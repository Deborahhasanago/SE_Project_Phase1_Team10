<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    header("Location: index.php");
    exit();
} else if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book'])) {
    header("Location: index.php");
    exit(); }
?>

<DOCTYPE! html>
<html>

<head> <title> Mindfulcare </title>
<link rel="stylesheet" href="landingpage.css">
    <link rel="icon" type="image/x-icon" href="./images/mind.ico"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
<header>
    <img class="images" src="./images/mind.ico" alt="logo">
    <nav>
        <ul class="topnav">
            <li><a href="#">Home</a></li>
            <li><a href="#" onclick="scrollToSection('about')">About</a></li>
            <li><a href="#" onclick="scrollToSection('services')">Services</a></li>
        </ul>
    </nav>
    <a class="button" href="index.php" name="login"><button>LOGIN</button></a>
</header>


<div class="banner">
    <img src="./images/Frame 80.png" alt="">
    <div class="text">
        <h2>Mental health is not a destination, it’s a journey.</h2>
    </div>
    <button class="contact">CONTACT</button>
  </div>

  <section class="work">
    <div class="container-fluid text-center">
        <div class="row">

            <div class="col-md-4">
                <div class="hours">
                    <div class="ico">
                    </div>
                    <h2>Opening Hours</h2>
                </div>
                <div class="time">
                    <div class="booking">MONDAY ---- FRIDAY</div>
                    <div class="booking">9AM ---- 4PM</div>
                <div class="booking">
                <button type="button" class="btn-white" name="book" onclick="window.location.href = 'index.php';">
                 <i class="material-symbols-outlined">
                  calendar_month
                  </i> BOOK
                  </button>
                </div>
                </div>
            
                <div class="time">
                    <div class="booking">SATURDAY  ----  SUNDAY</div>
                    <div class="booking">10AM  ----  2PM</div>
                <div class="booking">
                <button type="button" class="btn-white" name="book" onclick="window.location.href = 'index.php';">
                 <i class="material-symbols-outlined">
                  calendar_month
                  </i> BOOK
                  </button>
                </div>
                
                </div>
            </div>
            
        </div>
    </div>
  
    
    <section class = "sc-services" id="services">
        <div class="container">
            <div class = "services-content">
                <div class="title-box text-center">
                    <div class = "content-wrapper">
                        <h5 class = "title-box-name">SERVICES</h5>
                        <div class = "title-separator mx-auto"></div>
                        <p class = "text title-box-text">We provide you the best choices for you. Adjust it to your health needs and make sure you undergo treatment with our highly qualified doctors you can consult with us which type of service is suitable for your health.</p>
                    </div>
                </div>

                <div class = "services-list">
                    <div class = "services-item">
                        <div class = "item-icon">
                            <img src = "./images/loop.png" alt = "service icon">
                        </div>
                        <h5 class = "item-title fw-7">Search doctor</h5>
                        <p class = "text">Choose your doctor form thousands of specialist, general and trusted hospitals.</p>
                    </div>

                    <div class = "services-item">
                        <div class = "item-icon">
                            <img src = "./images/treatment.png" alt = "service icon">
                        </div>
                        <h5 class = "item-title fw-7">Online pharmacy</h5>
                        <p class = "text">Buy your medicines with our mobile application with a simple delivery system.</p>
                    </div>

                    <div class = "services-item">
                        <div class = "item-icon">
                            <img src = "./images/form.png" alt = "service icon">
                        </div>
                        <h5 class = "item-title fw-7">Consultation</h5>
                        <p class = "text">Free consultation with our trusted doctors and get the best recommendations.</p>
                    </div>
                    <button type="button" class="buttonlearn" onclick="scrollToSection('about')">Learn More</button>
                </div>
                    
                    
                    
            </div>
        </div>
    </section>


    

    <section class= "about" id="about">
        <div class = "image">
            <img class="abtus" src = "./images/abtus.png" alt = "service icon">
        </div>

        <div class = "content">
            <h2>About Us</h2>
            <span><!-- line here --></span>

            <p>Welcome to Mindfulcare, where compassionate care meets expertise in mental health. Our team specializes in personalized therapies to support your journey to wellness. Contact us today to start your path to a healthier mind.</p>


            <ul class = "icons">
                <li>
                    <i class = "fa fa-instagram"></i>
                </li>
                <li>
                    <i class = "fa fa-facebook"></i>
                </li>
                <li>
                    <i class = "fa fa-youtube"></i>
                </li>
            </ul>
        </div>
    </section>

    <script>
        function scrollToSection(sectionId) {
            var section = document.getElementById(sectionId);
            if (section) {
                section.scrollIntoView({ behavior: 'smooth' });
            }
        }
    </script>
</body>
</html>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2024 at 11:07 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mindfulcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `role` enum('admin','clinician','patient') NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `role`, `username`, `password`, `name`, `email`, `created_at`) VALUES
(1, 'admin', 'admin1', 'sara1234', 'Dora Smith', 'admin1@gmail.com', '2024-05-12'),
(2, 'clinician', 'clinician1', 'sara1234', 'Bea Donn', 'clinician1@gmail.com', '2024-05-12'),
(21, 'patient', 'patient6', 'deborah12345', 'Deborah Hasanago', 'dhasanago21@epoka.edu.al', '2024-05-16');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(60) NOT NULL,
  `message` varchar(250) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'pending' COMMENT 'pending, completed, cancelled',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name`, `date`, `time`, `email`, `phone`, `message`, `status`, `created_at`) VALUES
(2, 'Dora Simons', '2024-05-16', '20:47:00', 'sana@gmail.com', 267181919, 'Hi there.', 'pending', '2024-05-16 00:38:44'),
(3, 'Deborah Hsanago', '2003-01-28', '11:30:00', 'dhasanago21@epoka.edu.al', 695489932, 'Hi.', 'pending', '2024-05-16 17:46:17'),
(4, 'Deborah Hsanago', '2003-01-28', '11:30:00', 'dhasanago21@epoka.edu.al', 695489932, 'Hi.', 'pending', '2024-05-16 17:47:12'),
(5, '', '0000-00-00', '00:00:00', '', 0, '', 'pending', '2024-05-16 23:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `patient_records`
--

CREATE TABLE `patient_records` (
  `Id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `gender` enum('female','male') NOT NULL,
  `birthday` date NOT NULL,
  `diagnosis` varchar(150) NOT NULL,
  `treatment` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_records`
--

INSERT INTO `patient_records` (`Id`, `image`, `name`, `surname`, `gender`, `birthday`, `diagnosis`, `treatment`) VALUES
(1, 'assets/ehr/1715870597.png', 'Dona', 'Miller', 'female', '1996-07-20', 'OCD severe 1', 'Talking Therapy');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(100) NOT NULL,
  `birthday` date NOT NULL,
  `phone` int(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Id`, `name`, `image`, `birthday`, `phone`, `email`, `position`) VALUES
(1, 'Ana Miller J', 'assets/staff/1715874164.png', '1994-08-16', 695423789, 'anam.@gmail.com', 'Senior Clinician'),
(7, 'Klea Hoxha', 'assets/staff/1715874705.jpg', '1995-11-15', 2147483647, 'kleahoxha@gmail.com', 'Assisitant Clinc.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_records`
--
ALTER TABLE `patient_records`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient_records`
--
ALTER TABLE `patient_records`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php



if (!isset($_SESSION['username']) && !isset($_SESSION['id'])) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <style>
       * {
        box-sizing: border-box;
        padding: 0;
        margin: 0;
    }

    body {
        background-color: #C6E7D1; /* Set the background color for the entire page */
    }

    .container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: auto;
       
    
    }

     .container form{
    /* padding-top: 20px;
    padding-bottom: 30px; */
    border-radius: 5px;
    box-shadow: 0 5px 10px rgba(0,0,0,.1);
    text-align: center;
    width: 550px;
    background-color:white ;
     }  
        
    .container form p{
    margin-top: 10px;
    font-size: 20px;
    color:#333;
 }
 
 .container form p a{
    color:#d43223;
    font-style: normal;
 }
 
 .container form input,
 .container form select{
    width: 100%;
    padding:10px 15px;
    font-size: 17px;
    margin:8px 0;
    background: #eee;
    border-radius: 5px;
 }

 .container form select option{
    background: #fff;
 }

 .container .form-btn{
   display: inline-block;
   padding:10px 30px;
   font-size: 20px;
   color:white;
   margin:0 5px;
   text-transform: capitalize;
   cursor: pointer;
   background:#F09E54 ;
}
 
 .container form .form-btn:hover{
    background: rgb(235, 191, 50);
    color:white;
 }
    </style>

</head>
<body>

<div class="container" >

        <form class="border shadow p-3 " action="php/check-login.php" method="post" >
            <h1 class="text-center p-3">LOGIN</h1>
            
            <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger" role="alert">
                <?=$_GET['error']?> </div>
            <?php } ?>
            
            <div class="mb-3">
                <input type="text" class="form-control" name="username" id="username" required placeholder="enter your username">
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" id="password" required placeholder="enter your password">
            </div>
            <div class="mb-1">
            </div>
            <select class="form-select mb-3" name="role" aria-label="Default select example">
                <option selected value="admin">Admin</option>
                <option value="clinician">Clinician</option>
                <option value="patient">Patient</option>
            </select>
            
            <button type="submit" class="form-btn">LOGIN</button>
            <p>Don't have an account? <a href="registerform.php">Register now</a></p>
        </form>

    </div>
    <button class="btn btn-success" onclick="location.href='./landingpage.php'"><img src="./images/back.png" alt="">Go to homepage</button>
</body>
</html>
<?php } else {
    header("Location: login.php");
} ?>
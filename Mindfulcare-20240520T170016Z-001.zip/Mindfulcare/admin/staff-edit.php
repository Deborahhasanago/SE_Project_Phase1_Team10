<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                EDIT STAFF
                <a href="staff.php" class="btn btn-primary float-end">BACK</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
               <form action="code.php" method="POST" enctype="multipart/form-data">
               
               <?php 
               
               $paramResult = checkParamId('id');
               if(!is_numeric($paramResult)){
               echo '<h5>'.$paramResult.'</h5>';
               return false;
        
            }

        
            $staff = getById('staff',$paramResult);
             if($staff){

            if($staff['status'] == 200)
        {
                
                ?>

                
<input type="hidden" name="staffId"  value="<?= $staff['data']['Id'];?>">
               
                 <h5> Personal Information </h5>
               
               
                
               <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name"  value="<?= $staff['data']['name'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Upload Image</label>
                    <input type="file" name="image" class="form-control">
                     <img src="<?= $staff['data']['image'];?>" style="width:70px;height:70px;" alt="img"/>
                </div>
                <div class="mb-3">
                    <label>Birthday</label>
                    <input type="date" name="birthday" value="<?= $staff['data']['birthday'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?= $staff['data']['phone'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= $staff['data']['email'];?>" required class="form-control">
                </div>

                <div class="mb-3">
                    <label>Postion</label>
                    <input type="text" name="position"  value="<?= $staff['data']['position'];?>"required class="form-control">
                </div>

                <div class="mb-3 text-end">
                    <button type="submit" name="updateStaff" class="btn btn-primary">Save Staff</button>


            <?php
    }
    
    else{

    echo "<h5>No such data found!</h5>"; 
        
    }
      
    }else{

        echo "<h5>Something Went Wrong!</h5>"; 
        }
          
            ?>
                
               </form>
        </div>
            </div>
        </div>
    </div>
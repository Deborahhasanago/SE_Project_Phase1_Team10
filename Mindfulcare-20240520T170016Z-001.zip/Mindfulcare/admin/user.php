<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                USER LISTS
                <a href="user-create.php" class="btn btn-primary float-end">ADD USERS</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
                <table id="myTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Role</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                    </tr>
            </thead>
            <tbody>
                <?php 
                
                $users = getAll('admin');
                if(mysqli_num_rows($users) > 0){
                
                    foreach($users as $userItem){
                        ?>
                           <tr>
                <td><?= $userItem['id']; ?></td>
                <td><?= $userItem['role']; ?></td>
                <td><?= $userItem['username']; ?></td>
                <td><?= $userItem['password']; ?></td>
                <td><?= $userItem['name']; ?></td>
                <td><?= $userItem['email']; ?></td>
                <td>
                    <a href="user-edit.php?id=<?= $userItem['id']; ?>" class="btn btn-success btn-sm">EDIT</a>
                    <a href="user-delete.php?id=<?= $userItem['id']; ?>" class="btn btn-danger mx-2"
                    onclick="return confirm('Are you sure you want to delete this data?')">DELETE</a>
                </td>
                </tr>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <tr>
                    <td colspan="7">No Record Found</td>
                    </tr>
                    <?php
                }
                ?>
                
            </tbody>
</table>
        </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
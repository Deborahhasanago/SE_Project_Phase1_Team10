<?php

require '../configure/function.php';

$paraResult= checkParamId('id');
if(is_numeric($paraResult)){

    $userId= validate($paraResult);

    $user = getById('admin', $userId);
   if( $user['status'] == 200){

    $userDeleteRes= deleteQuery('admin', $userId);
    
    if($userDeleteRes){

        redirect('user.php', 'User Deleted Successfully');
    }
    else{

        redirect('user.php', 'Something Went Wrong');
    }
   }
   else{

    redirect('user.php', $user['message']);
   }
}
else{
 redirect('user.php', $paraResult);
}



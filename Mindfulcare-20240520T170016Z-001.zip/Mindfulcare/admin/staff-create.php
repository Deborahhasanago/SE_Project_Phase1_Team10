<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                ADD DOCTOR
                <a href="staff.php" class="btn btn-primary float-end">BACK</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
               <form action="code.php" method="POST" enctype="multipart/form-data">
               <h5> Personal Information </h5>
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Upload Image</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Birthday</label>
                    <input type="date" name="birthday" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Phone</label>
                    <input type="text" name="phone" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" required class="form-control">
                </div>

                <div class="mb-3">
                    <label>Postion</label>
                    <input type="text" name="position" required class="form-control">
                </div>

                <div class="mb-3 text-end">
                    <button type="submit" name="saveStaff" class="btn btn-primary">Save Doctor</button>

                
                
               </form>
        </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
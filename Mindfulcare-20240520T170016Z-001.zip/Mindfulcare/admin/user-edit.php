<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                Edit User 
                <a href="user.php" class="btn btn-danger float-end">BACK</a>
            </h4>
          </div>
          <div class="card-body">
          <?= alertMessage(); ?>
            
          <form action="code.php" method="POST">
          
          <?php
          $paramResult = checkParamId('id');
          if(!is_numeric($paramResult)){
            echo '<h5>'.$paramResult.'</h5>';
            return false;
        }

        $user = getById('admin',checkParamId('id'));
        if($user['status'] == 200){

            ?>

      <input type="hidden" name="userId" value="<?= $user['data']['id'];?>" required >
               <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" value="<?= $user['data']['name'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" value="<?= $user['data']['email'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" value="<?= $user['data']['username'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" value="<?= $user['data']['password'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Select Role</label>
                <select name="role" required class="form-select">
                 <option value="">Select Role</option>   
                 <option value="admin" <?= $user['data']['role'] == 'admin' ? 'selected':'' ;?>>Admin</option>
                 <option value="patient" <?= $user['data']['role'] == 'patient' ? 'selected':'' ;?>>Patient</option>
                 <option value="clinician" <?= $user['data']['role'] == 'clinician' ? 'selected':'' ;?>>Clinician</option>
                </select>
                </div>
                <div class="mb-3">
                <button type="submit" name="updateUser" class="btn btn-primary">UPDATE</button>
                </div>
            <?php
        }
        else
        {

            echo '<h5>'.$user['message'].'</h5>';
        }
          ?>
            
          </form>
            
          </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
<?php
require '../configure/function.php';
 
if (isset($_POST['saveUser'])){

    $name=validate($_POST['name']);
    $username=validate($_POST['username']);
    $password=validate($_POST['password']);
    $email=validate($_POST['email']);
    $role=validate($_POST['role']);
    
    
    if ($name != '' || $username != '' || $password != '' || $email != ''){
     $query= "INSERT INTO admin (role, username, password, name, email) VALUES('$role', '$username', '$password', '$name', '$email')";
     $result=mysqli_query($conn,$query);   

if ($result){
    redirect('user.php', 'User Added Successfully');
}else{
    redirect('user-create.php', 'Something went wrong');
}
    }
    else {
        redirect('user-create.php', 'Please fill all the input fields');
    }
 }

 if(isset($_POST['updateUser'])){

    $name=validate($_POST['name']);
    $username=validate($_POST['username']);
    $password=validate($_POST['password']);
    $email=validate($_POST['email']);
    $role=validate($_POST['role']);
    
    $userId = validate($_POST['userId']);
    $user = getById('admin', $userId);
    if($user['status'] != 200){

        redirect('user-edit.php?id='.$userId, 'No Such Id Found');
    }
    
    if($name != '' || $username != '' || $password != '' || $email != '')
    {
     $query= "UPDATE admin SET 
     role='$role', 
     username='$username', 
     password='$password', 
     name='$name', 
     email='$email'
     WHERE id='$userId'";
     
     $result=mysqli_query($conn,$query);   

if ($result){
    redirect('user.php', 'Updated Successfully');
}else{
    redirect('user-create.php', 'Something went wrong');
}
    }
    else {
        redirect('user-create.php', 'Please fill all the input fields!');
    }
 }


 If(isset($_POST['saveStaff'])){

    
    $name=validate($_POST['name']);

    if($_FILES['image']['size'] > 0){

        $image = $_FILES['image']['name'];
        
        $imgFileTypes = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if($imgFileTypes != 'jpg' && $imgFileTypes != 'jpeg' && $imgFileTypes != 'png'){
            redirect('staff.php', 'Sorry, only JPG, JPEG, PNG images'); 
        }
        
        $path = "./assets/staff/";
        $imgExt = pathinfo($image, PATHINFO_EXTENSION);
        $filename = time().'.'.$imgExt;
    
    
        $finalImage = 'assets/staff/'.$filename;
    
    }else{
        
        $finalImage=NULL;
    }

    
    $birthday=validate($_POST['birthday']);
    $phone=validate($_POST['phone']);
    $email=validate($_POST['email']);
    $position=validate($_POST['position']);

    $query= "INSERT INTO staff (name,image,birthday,phone,email,position) VALUES ('$name','$finalImage','$birthday','$phone','$email','$position')";

    $result=mysqli_query($conn,$query);
    if ($result){
        if($_FILES['image']['size'] > 0){
        move_uploaded_file($_FILES['image']['tmp_name'], $path.$filename);
    }

        redirect('staff.php', 'Staff Added Successfully');
    }else{
        redirect('staff.php', 'Something went wrong!');
    }

 }

 if(isset($_POST['updateStaff'])){

    $staffId=validate($_POST['staffId']);
    $name=validate($_POST['name']);
    
    
    $staff = getById('staff', $staffId);
    

    if($_FILES['image']['size'] > 0){

        $image = $_FILES['image']['name'];
        
        $imgFileTypes = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if($imgFileTypes != 'jpg' && $imgFileTypes != 'jpeg' && $imgFileTypes != 'png'){
            redirect('staff.php', 'Sorry, only JPG, JPEG, PNG images'); 
        }

        $path = "./assets/staff/";

        $deleteImage = "./".$staff['data']['image'];
        if(file_exists($deleteImage)){
            unlink($deleteImage);


        }

        $imgExt = pathinfo($image, PATHINFO_EXTENSION);
        $filename = time().'.'.$imgExt;
    
    
        $finalImage = 'assets/staff/'.$filename;
    
    }else{
        
        $finalImage=$staff['data']['image'];
    }
     
    
    $birthday=validate($_POST['birthday']);
    $phone=validate($_POST['phone']);
    $email=validate($_POST['email']);
    $position=validate($_POST['position']);

    $query = "UPDATE staff SET name ='$name', image = '$finalImage', birthday ='$birthday', phone ='$phone', email = '$email', 
    position = '$position' WHERE Id='$staffId' ";
    $result = mysqli_query($conn, $query);
    if($result){

        if($_FILES['image']['size'] > 0){
            move_uploaded_file($_FILES['image']['tmp_name'], $path.$filename);
        }
    
            redirect('staff-edit.php?id='.$staffId, 'Staff Updated Successfully');
        }else{
            redirect('staff.php?id='.$staffId, 'Something went wrong!');
        }
    }
 

   
<?php  
session_start(); 

if (isset($_SESSION['id'])) {
    // Unset or remove the session variables related to the user
    unset($_SESSION['name']);
    unset($_SESSION['id']);
    unset($_SESSION['role']);
    unset($_SESSION['username']);

    // Destroy the session data
    session_destroy();

    // Redirect the user to the login page or any other desired page
    header("Location: ../index.php");
    exit(); // Ensure no further code is executed after the redirect
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: ../index.php");
    exit(); // Ensure no further code is executed after the redirect
}



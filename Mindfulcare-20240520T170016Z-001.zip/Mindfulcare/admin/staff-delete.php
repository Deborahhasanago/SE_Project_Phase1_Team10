<?php

require '../configure/function.php';

$paraResult= checkParamId('id');
if(is_numeric($paraResult)){

    $staffId= validate($paraResult);

    $staff = getById('staff', $staffId);
   if( $staff['status'] == 200){

    $staffDeleteRes= deleteQuery('staff', $staffId);
    
    if($staffDeleteRes){
        
        $deleteImage = "../".$staff['data']['image'];
        if(file_exists($deleteImage)){
            unlink($deleteImage);


        }

        redirect('staff.php', 'Staff Deleted Successfully');
    }
    else{

        redirect('staff.php', 'Something Went Wrong');
    }
   }
   else{

    redirect('staff.php', $staff['message']);
   }
}
else{
 redirect('staff.php', $paraResult);
}





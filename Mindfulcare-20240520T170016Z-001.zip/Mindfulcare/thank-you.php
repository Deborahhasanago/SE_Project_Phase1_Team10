<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<?php require './configure/function.php'; ?>

<div class="py-5 bg-secondary">
<div class="container">
    <h4 class="text-white text-center">Thank you!</h4>
</div>
</div>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-body bg-light shadow-sm text-center">
                
                    <h4>Your Appoinment Has Been Submmited!</h4>
                    <!-- <p>Thank you for reaching out! We will try to get back to you in the earliest!</p> -->
               <div>
               <?= alertMessage(); ?>
                </div>
                <div class="mt-4">
                        <a href="index.php" class="btn btn-primary">LOGOUT</a>
                    </div>
            </div>
        </div>
    </div>
    </div>
</div>




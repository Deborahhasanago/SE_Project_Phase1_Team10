<?php 

require './configure/function.php';

if(isset($_POST['bookBtn'])){
    $name=validate($_POST['name']);
    $date=validate($_POST['date']);
    $time=validate($_POST['time']);
    $email=validate($_POST['email']);
    $phone=validate($_POST['phone']);
    $message=validate($_POST['message']);
    
    $query= "INSERT INTO appointment (name,date,time,email,phone,message) VALUES('$name','$date','$time','$email','$phone','$message')";
    $result= mysqli_query($conn, $query);

    if($result){
        redirect('thank-you.php', 'Thank you for reaching out! We will try to get back to you in the earliest time.');
    }else{
        redirect('thank-you.php', 'Something Went Wrong');

    }

}





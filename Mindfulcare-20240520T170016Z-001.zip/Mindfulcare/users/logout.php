<?php  
session_start(); 

if (isset($_SESSION['id'])) {
    
    unset($_SESSION['name']);
    unset($_SESSION['id']);
    unset($_SESSION['role']);
    unset($_SESSION['username']);

    
    session_destroy();

    
    header("Location: ../index.php");
    exit(); 
} else {
    
    header("Location: ../index.php");
    exit(); 
}
<?php

require '../configure/function.php';

$paraResult= checkParamId('id');
if(is_numeric($paraResult)){

    $ehrId= validate($paraResult);

    $ehr = getById('patient_records', $ehrId);
   if( $ehr['status'] == 200){

    $ehrDeleteRes= deleteQuery('patient_records', $ehrId);
    
    if($ehrDeleteRes){
        

        redirect('ehr.php', 'Record Deleted Successfully');
    }
    else{

        redirect('ehr.php', 'Something Went Wrong');
    }
   }
   else{

    redirect('ehr.php', $ehr['message']);
   }
}
else{
 redirect('ehr.php', $paraResult);
}
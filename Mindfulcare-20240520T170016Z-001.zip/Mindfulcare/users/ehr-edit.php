<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                EDIT STAFF
                <a href="ehr.php" class="btn btn-primary float-end">BACK</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
               <form action="code.php" method="POST" enctype="multipart/form-data">
               
               <?php 
               
               $paramResult = checkParamId('id');
               if(!is_numeric($paramResult)){
               echo '<h5>'.$paramResult.'</h5>';
               return false;
        
            }

        
            $ehr = getById('patient_records',$paramResult);
             if($ehr){

            if($ehr['status'] == 200)
        {
                
                ?>

                
<input type="hidden" name="ehrId"  value="<?= $ehr['data']['Id'];?>">
               
                 <h5> General Information </h5>
               
               
                 <div class="mb-3">
                    <label>Upload Image</label>
                    <input type="file" name="image" class="form-control">
                     <img src="<?= $ehr['data']['image'];?>" style="width:70px;height:70px;" alt="img"/>
                </div>
               <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name"  value="<?= $ehr['data']['name'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Surname</label>
                    <input type="text" name="surname"  value="<?= $ehr['data']['surname'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                <label>Select Role</label>
                <select name="gender" required class="form-select">
                 <option value="">Select Role</option>   
                 <option value="female" <?= $ehr['data']['gender'] == 'female' ? 'selected':'' ;?>>Female</option>
                 <option value="male" <?= $ehr['data']['gender'] == 'male' ? 'selected':'' ;?>>Male</option>
                </select>
                </div>
                <div class="mb-3">
                    <label>Birthday</label>
                    <input type="date" name="birthday" value="<?= $ehr['data']['birthday'];?>" required class="form-control">
                </div>
                <h5> Patient Histroy</h5>
                
                <div class="mb-3">
                    <label>Diagnosis</label>
                    <input type="text" name="diagnosis" value="<?= $ehr['data']['diagnosis'];?>" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Treatment</label>
                    <input type="text" name="treatment" value="<?= $ehr['data']['treatment'];?>" required class="form-control">
                </div>

                <div class="mb-3 text-end">
                    <button type="submit" name="updateEhr" class="btn btn-primary">Save</button>


            <?php
    }
    
    else{

    echo "<h5>No such data found!</h5>"; 
        
    }
      
    }else{

        echo "<h5>Something Went Wrong!</h5>"; 
        }
          
            ?>
                
               </form>
        </div>
            </div>
        </div>
    </div>

<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                Electronic Health Records
                <a href="ehr-create.php" class="btn btn-primary float-end">ADD RECORD</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
                <table id="myTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Diagnosis</th>
                    <th>Treatment</th>
                    <th>Action</th>
                    </tr>
            </thead>
            <tbody>
            
            <?php 
                
                $records = getAll('patient_records');
                if(mysqli_num_rows($records) > 0){
                
                    foreach($records as $item){
                        ?>
                           <tr>
                <td><?= $item['Id']; ?></td>
                <td><?= $item['name']; ?></td>
                <td><?= $item['surname']; ?></td>
                <td><?= $item['gender']; ?></td>
                <td><?= $item['birthday']; ?></td>
                <td><?= $item['diagnosis']; ?></td>
                <td><?= $item['treatment']; ?></td>
                <td>
                    <a href="ehr-edit.php?id=<?= $item['Id']; ?>" class="btn btn-success btn-sm">EDIT</a>
                    <a href="ehr-delete.php?id=<?= $item['Id']; ?>" class="btn btn-danger mx-2"
                    onclick="return confirm('Are you sure you want to delete this data?')">DELETE</a>
                </td>
                </tr>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <tr>
                    <td colspan="8">No Record Found</td>
                    </tr>
                    <?php
                }
                ?>
                
            </tbody>
</table>
        </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
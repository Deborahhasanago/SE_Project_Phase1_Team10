<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                Edit User 
                <a href="book.php" class="btn btn-danger float-end">BACK</a>
            </h4>
          </div>
          <div class="card-body">
          <?= alertMessage(); ?>
            
          <form action="code.php" method="POST">
          
          <?php
          $paramResult = checkParamId('id');
          if(!is_numeric($paramResult)){
            echo '<h5>'.$paramResult.'</h5>';
            return false;
        }

        $user = getById('appointment',checkParamId('id'));
        if($user['status'] == 200){

            ?>

      <input type="hidden" name="bookid" value="<?= $user['data']['id'];?>" required >
               <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" value="<?= $user['data']['name'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Date</label>
                <input type="date" name="date" value="<?= $user['data']['date'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Time</label>
                <input type="time" name="time" value="<?= $user['data']['time'];?>" required class="form-control">
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" value="<?= $user['data']['email'];?>" required class="form-control">
            </div>
                <div class="mb-3">
                <button type="submit" name="updateAppoint" class="btn btn-primary">UPDATE</button>
                </div>
            <?php
        }
        else
        {

            echo '<h5>'.$user['message'].'</h5>';
        }
          ?>
            
          </form>
            
          </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
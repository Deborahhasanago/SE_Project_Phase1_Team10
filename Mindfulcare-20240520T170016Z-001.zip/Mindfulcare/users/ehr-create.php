<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                ADD EHRs
                <a href="ehr.php" class="btn btn-primary float-end">BACK</a>
            </h4>
          </div>
                <div class="card-body">
        
                <?= alertMessage(); ?>
                
               <form action="code.php" method="POST" enctype="multipart/form-data">
               <h5> General Information </h5>
               <div class="mb-3">
                    <label>Upload Image</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Surname</label>
                    <input type="text" name="surname" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Gender</label>
                    <select name="gender" class="form-control">
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Birthday</label>
                    <input type="date" name="birthday" required class="form-control">
                </div>

                <h5> Patient History </h5>
                <div class="mb-3">
                    <label>Diagnosis</label>
                    <input type="text" name="diagnosis" required class="form-control">
                </div>
                <div class="mb-3">
                    <label>Treatment</label>
                    <input type="text" name="treatment" required class="form-control">
                </div>
                <div class="mb-3 text-end">
                    <button type="submit" name="saveEhr" class="btn btn-primary">Save</button>

                
                
               </form>
        </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
<?php  include('includes/header.php');?>

<div class="row">
      <div class="col-md-12">
            <?= alertMessage(); ?>
      </div>
        
   <div class="col-md-3 mb-4">
   <div class=" card card-body p-3">
              <p class="text-sm mb-0 text-capitalize font-weight-bold">Total Appoinments</p>
                    <h5 class="font-weight-bolder mb-0">
                        <?= getCount('appointment') ?>
                  
                      </h5>
                </div>
          </div>

    <div class="col-md-3 mb-4">
   <div class=" card card-body p-3">
              <p class="text-sm mb-0 text-capitalize font-weight-bold">EHRs</p>
                    <h5 class="font-weight-bolder mb-0">
                    <?= getCount('patient_records') ?>
                      </h5>
                </div>
          </div>

    </div>

    <div class="py-2 bg-light">
      
     <div class="container ">
      <h4 class="text-dark">Current Patients</h4>
     </div>
    
</div>



<div class="py-5 bg-light"></div>
<div class="container">
      <div class="row">
            <?php
            
            $recordsQuery = "SELECT * FROM patient_records WHERE Id";
            $result = mysqli_query($conn, $recordsQuery);
            if($result){
                  if($result){
                        if(mysqli_num_rows($result) > 0){
                              foreach($result as $row){

                                    ?>

                         <div class="col-md-3 mb-3">
                         <div class="card border-success shadow-sm">
                         <?php if($row['image'] != '') : ?>
                        <img src="<?= $row['image']; ?>" class="w-100" alt="Img"/>
                         <?php else : ?>
                         <img src="assets/ehr/" class="w-100 rounded" alt="Img"/>
                         <?php endif ; ?>
                         
                         <div class="card-body">
                            <h5><?= $row['name']; ?></h5>  
                            <p>
                            <?= $row['diagnosis']; ?>
                            </p>
                            <a href="ehr.php?slug" class="btn btn-success">OPEN</a>


                        </div>


                  </div>


            </div>
                                    <?php
                              }

                        }
                  }

            }else{
                  echo "<h5>Something Went Wrong!</h5>";
            }
            
            
            ?>
            
      </div>
</div>

    <?php include('includes/footer.php'); ?>
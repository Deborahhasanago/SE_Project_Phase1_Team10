<?php

require '../configure/function.php';

$paraResult= checkParamId('id');
if(is_numeric($paraResult)){

    $AppointId= validate($paraResult);

    $appointment = getById('appointment', $AppointId);
   if( $appointment['status'] == 200){

    $staffDeleteRes= deleteQuery('appointment', $AppointId);
    
    if($staffDeleteRes){
        

        redirect('book.php', 'Appointment Deleted Successfully');
    }
    else{

        redirect('book.php', 'Something Went Wrong');
    }
   }
   else{

    redirect('book.php', $appointment['message']);
   }
}
else{
 redirect('book.php', $paraResult);
}
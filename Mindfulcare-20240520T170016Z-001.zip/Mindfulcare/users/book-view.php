<?php include('includes/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
           <div class="card-header">
            <h4>
                View Appoinment
                <a href="book.php" class="btn btn-danger mb-0 float-end">BACK</a>
            </h4>
          </div>
                <div class="card-body">
                <?= alertMessage(); ?>
                <?php 
               
               $paramResult = checkParamId('id');
               if(!is_numeric($paramResult)){
               echo '<h5>'.$paramResult.'</h5>';
               return false;
        
            }

        
            $appointment = getById('appointment',$paramResult);
             if($appointment){

            if($appointment['status'] == 200){
         ?>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                            <td width="20%">Appoint.ID</td>
                            <td><?= $appointment['data']['id']; ?></td>
                            </tr>
                            <tr>
                            <td>Name</td>
                            <td><?= $appointment['data']['name']; ?></td>
                            </tr><tr>
                            <td>Date</td>
                            <td><?= $appointment['data']['date']; ?></td>
                            </tr><tr>
                            <td>Time</td>
                            <td><?= $appointment['data']['time']; ?></td>
                            </tr><tr>
                            <td>Email</td>
                            <td><?= $appointment['data']['email']; ?></td>
                            </tr>
                            <tr>
                            <td>Phone</td>
                            <td><?= $appointment['data']['phone']; ?></td>
                            </tr>
                            <tr>
                            <td>Message</td>
                            <td><?= $appointment['data']['message']; ?></td>
                            </tr>
                            <td>Status</td>
                            <td><?= $appointment['data']['status']; ?></td>
                            </tr>
                            <td>Created At(Booking Date)</td>
                            <td><?= $appointment['data']['created_at']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="mt-3">
                        <div class="card border card-body">
                       
                        
                       
                        <form action="code.php" method="POST">
                        <input type="hidden" name="bookid" value="<?= $appointment['data']['id']; ?>"/>
                      
                        <div class="row">
                                <div class="col-md-4">
                                    <label> Update Status</label>
                                    <select name="status" class="form-select">
                                        <option value="pending" 
                                        <?= $appointment['data']['status'] == 'pending' ? 'selected':''; ?>>
                                            pending
                                        </option>
                                        <option value="completed"
                                        <?= $appointment['data']['status'] == 'completed' ? 'selected':''; ?>>
                                            completed
                                        </option>
                                        <option value="cancelled"
                                        <?= $appointment['data']['status'] == 'cancelled' ? 'selected':''; ?>>
                                            cancelled
                                        </option>
                                    </select>
                                </div>
                                <div class="col-md-8">
                                    <br/>
                                    <button  name="updateStatus" class="btn btn-primary" type="submit">UPDATE</button>
                                </div>
                            </div>
                       </form>
                           
                        </div>
                    </div>
                    <?php
                }
                else{
                    echo "<h5>No record found!</h5>";
                }
        }
        ?>

                </div>
                </div>
                </div>
            </div>
<?php include('includes/footer.php'); ?>
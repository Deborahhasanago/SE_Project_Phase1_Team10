<?php
require '../configure/function.php';

if(isset($_POST['updateStatus'])){
    $bookid= validate($_POST['bookid']);
    $status = validate($_POST['status']);

    $query= "UPDATE appointment SET status='$status' WHERE id='$bookid'";
    $result= mysqli_query($conn,$query);

    if($result){
        redirect('book-view.php?id='.$bookid, 'Status Updated');
    }else{
        redirect('book-view.php?id='.$bookid, 'Something Went Wrong!');
    }

}

if(isset($_POST['updateAppoint'])){

    $name=validate($_POST['name']);
    $date=validate($_POST['date']);
    $time=validate($_POST['time']);
    $email=validate($_POST['email']);
    
    
    $Appointid = validate($_POST['bookid']);
    $appointment = getById('appointment', $Appointid);
    if($appointment['status'] != 200){

        redirect('book-edit.php?id='.$Appointid, 'No Such Id Found');
    }
    
    if($name != '' || $date != '' || $time != '' || $email != '')
    {
     $query= "UPDATE appointment SET 
     name='$name', 
     date='$date', 
     time='$time',  
     email='$email'
     WHERE id='$Appointid'";
     
     $result=mysqli_query($conn,$query);   

if ($result){
    redirect('book.php', 'Updated Successfully');
}else{
    redirect('book-edit.php', 'Something went wrong');
}
    }
    else {
        redirect('user-edit.php', 'Please fill all the input fields!');
    }
 }

 If(isset($_POST['saveEhr'])){

    
    

    if ($_FILES['image']['size'] > 0) {
        $image = $_FILES['image']['name'];
        
        $imgFileTypes = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($imgFileTypes != 'jpg' && $imgFileTypes != 'jpeg' && $imgFileTypes != 'png') {
            redirect('ehr.php', 'Sorry, only JPG, JPEG, PNG images allowed'); 
        }
        
        $path = "./assets/ehr/";
        $imgExt = pathinfo($image, PATHINFO_EXTENSION);
        $filename = time().'.'.$imgExt;
        $finalImage = 'assets/ehr/'.$filename;
        
        move_uploaded_file($_FILES['image']['tmp_name'], $path.$filename);
    } else {
        $finalImage = NULL;
    }
    
    $name = validate($_POST['name']);
    $surname = validate($_POST['surname']);
    $gender = validate($_POST['gender']);
    $birthday = validate($_POST['birthday']);
    $diagnosis = validate($_POST['diagnosis']);
    $treatment = validate($_POST['treatment']);
    
    $query = "INSERT INTO patient_records (image, name, surname, gender, birthday, diagnosis, treatment) 
              VALUES ('$finalImage', '$name', '$surname', '$gender', '$birthday', '$diagnosis', '$treatment')";
    
    $result = mysqli_query($conn, $query);
    if ($result) {
        redirect('ehr.php', 'Record Added Successfully');
    } else {
        redirect('ehr.php', 'Something went wrong!');
    }
}

if(isset($_POST['updateEhr'])){

    $ehrId = validate($_POST['ehrId']);
    
    
    
    $ehr = getById('patient_records', $ehrId);
    

    if($_FILES['image']['size'] > 0){

        $image = $_FILES['image']['name'];
        
        $imgFileTypes = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if($imgFileTypes != 'jpg' && $imgFileTypes != 'jpeg' && $imgFileTypes != 'png'){
            redirect('ehr.php', 'Sorry, only JPG, JPEG, PNG images'); 
        }

        $path = "./assets/ehr/";

        $deleteImage ="./".$ehr['data']['image'];
        if(file_exists($deleteImage)){
            unlink($deleteImage);


        }

        $imgExt = pathinfo($image, PATHINFO_EXTENSION);
        $filename = time().'.'.$imgExt;
    
    
        $finalImage = 'assets/ehr/'.$filename;
    
    }else{
        
        $finalImage=$ehr['data']['image'];
    }
     
    $name=validate($_POST['name']);
    $surname=validate($_POST['surname']);
    $gender=validate($_POST['gender']);
    $birthday=validate($_POST['birthday']);
    $diagnosis=validate($_POST['diagnosis']);
    $treatment=validate($_POST['treatment']);
    

    $query = "UPDATE patient_records SET image = '$finalImage', name ='$name', surname ='$surname', gender ='$gender', birthday ='$birthday', diagnosis ='$diagnosis', treatment = '$treatment' 
     WHERE Id='$ehrId'";
    $result = mysqli_query($conn, $query);
    if($result){

        if($_FILES['image']['size'] > 0){
            move_uploaded_file($_FILES['image']['tmp_name'], $path.$filename);
        }
    
            redirect('ehr-edit.php?id='.$ehrId, 'Record Updated Successfully');
        }else{
            redirect('ehr.php?id='.$ehrId, 'Something went wrong!');
        }
    }
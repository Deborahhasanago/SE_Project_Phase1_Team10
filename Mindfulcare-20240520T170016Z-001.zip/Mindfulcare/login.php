<?php
session_start();
include "./configure/db_conn.php";

if (isset($_SESSION['username']) && isset($_SESSION['id'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: ./admin/admin.php");
        exit(); // Always exit after header redirection
    } elseif ($_SESSION['role'] == 'clinician') {
        header("Location: ./users/clinician.php");
        exit();
    } else {
        header("Location: appointment.php");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
